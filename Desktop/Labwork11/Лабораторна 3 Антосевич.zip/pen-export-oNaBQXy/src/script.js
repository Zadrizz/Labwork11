// Завдання 1
console.log(Math.floor(Math.random() * 100));

// Завдання 2
let num = 123;
let str = "hello";
let bool = true;
console.log(num, str, bool);

// Завдання 3
let a = 10;
let b = 20;
let sum = a + b;
console.log(sum);

// Завдання 4
// Файл script.js створюється окремо і підключається до index.html

// Завдання 5
let age = prompt("Введіть ваш вік:");
console.log("Ваш вік " + age);

// Завдання 6
let quantity = prompt("Введіть кількість купленого товару:");
let price = prompt("Введіть ціну за одиницю:");
let total = quantity * price;
console.log("Сума покупки: " + total);

// Завдання 7
let number = prompt("Введіть число:");
if (number < 0) {
  console.log("Число від'ємне");
} else {
  console.log("Число додатнє або нуль");
}

// Завдання 8
let day = prompt("Введіть номер дня тижня:");
switch (day) {
  case "1":
    console.log("Понеділок");
    break;
  case "2":
    console.log("Вівторок");
    break;
  case "3":
    console.log("Середа");
    break;
  case "4":
    console.log("Четвер");
    break;
  case "5":
    console.log("П'ятниця");
    break;
  case "6":
    console.log("Субота");
    break;
  case "7":
    console.log("Неділя");
    break;
  default:
    console.log("Неправильний номер дня тижня");
}

// Завдання 9
for (let i = 1; i <= 10; i++) {
  console.log("6 * " + i + " = " + 6 * i);
}

// Завдання 10
let n = 5;
let arr = [1, 2, -3, 4, 5];
console.log(arr[2] ** 2, arr[0] + arr[n - 1]);
let negativeSum = 0;
for (let i = 0; i < n; i++) {
  if (arr[i] < 0) {
    negativeSum += arr[i] ** 2;
  }
}
console.log(negativeSum);

// Завдання 11
// Створюємо об'єкт машини
const car = {
  ownerName: 'John',
  modelName: 'Toyota',
  engineVolume: 2.0
}

// Створюємо масив машин з різними об'ємами двигуна
const cars = [
  {
    ownerName: 'Mary',
    modelName: 'Honda',
    engineVolume: 1.5
  },
  {
    ownerName: 'Bob',
    modelName: 'Nissan',
    engineVolume: 2.2
  },
  {
    ownerName: 'Jane',
    modelName: 'Mazda',
    engineVolume: 1.8
  }
]

// Знаходимо машину з мінімальним об'ємом двигуна
let minEngineVolume = Infinity
let minEngineVolumeCar

for (let i = 0; i < cars.length; i++) {
  const car = cars[i]
  if (car.engineVolume < minEngineVolume) {
    minEngineVolume = car.engineVolume
    minEngineVolumeCar = car
  }
}

// Виводимо машину з мінімальним об'ємом двигуна
console.log(`Машина з мінімальним об'ємом двигуна: ${minEngineVolumeCar.modelName} (${minEngineVolumeCar.ownerName}, ${minEngineVolumeCar.engineVolume} л)`)



//Завдання 12
// Запитуємо користувача чотири числа
const a = parseFloat(prompt('Введіть число a'))
const b = parseFloat(prompt('Введіть число b'))
const c = parseFloat(prompt('Введіть число c'))
const d = parseFloat(prompt('Введіть число d'))

// Знаходимо мінімальні числа з a та b, та з c та d
const minAB = Math.min(a, b)
const minCD = Math.min(c, d)

// Знаходимо максимальне число з minAB та minCD
const maxMin = Math.max(minAB, minCD)

// Виводимо результат
console.log(`max{min(a, b), min(c, d)} = ${maxMin}`)


//Завдання 13
// Задайте слово, виведіть його довжину та запишіть його в зворотному порядку.
let word = "hello";
console.log(`Довжина слова: ${word.length}`);
let reversedWord = "";
for (let i = word.length - 1; i >= 0; i--) {
  reversedWord += word[i];
}
console.log(`Зворотнє слово: ${reversedWord}`);
