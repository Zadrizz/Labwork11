let persons = [
  { name: 'John', age: 23, city: 'Boston' },
  { name: 'Sarah', age: 29, city: 'New York' },
  { name: 'Michael', age: 35, city: 'Los Angeles' },
  { name: 'Emily', age: 27, city: 'Chicago' },
  { name: 'David', age: 31, city: 'San Francisco' }
];

persons.groupName = 'A';
persons.teacher = 'Joan Doe';
persons.year = '2023';

// Використання циклу for
for(let i = 0; i < persons.length; i++) {
  console.log(persons[i]);
}

// Використання циклу for...in
for(let key in persons) {
  console.log(`${key}: ${persons[key]}`);
}

// Використання циклу forEach
persons.forEach((person) => {
  console.log(person);
});

// Вивід властивостей масиву
console.log(`groupName: ${persons.groupName}`);
console.log(`teacher: ${persons.teacher}`);
console.log(`year: ${persons.year}`);



// завдання 2
let defaults = { mode: 'test', debugLevel: 'error', logFolder: 'root' };
let userSetting = { mode: 'production', debugLevel: 'trace' };

// Функція для об'єднання властивостей двох об'єктів
function mergeSettings(defaults, userSetting) {
  return Object.assign({}, defaults, userSetting);
}

// Використання функції
let mergedSettings = mergeSettings(defaults, userSetting);
console.log(mergedSettings);

// Використання Spread Operator
let mergedSettings2 = { ...defaults, ...userSetting };
console.log(mergedSettings2);

// Використання циклу for...in
let mergedSettings3 = {};

for(let key in defaults) {
  if(key in userSetting) {
    mergedSettings3[key] = userSetting[key];
  } else {
    mergedSettings3[key] = defaults[key];
  }
}

console.log(mergedSettings3);



//завдання 3
let person = { 
  name: 'John', 
  age: 23, 
  city: 'Boston', 
  get birthYear() {
    return new Date().getFullYear() - this.age;
  }
};

// Використання геттера для отримання року народження
console.log(person.birthYear);





//завдання 4
let arr1 = [1, 2, 3];
let arr2 = [4, 5, 6];

// Використання методу concat()
let combinedArr1 = arr1.concat(arr2);
console.log(combinedArr1);

// Використання spread operator (...)
let combinedArr2 = [...arr1, ...arr2];
console.log(combinedArr2);

// Використання методу push()
let combinedArr3 = arr1.push(...arr2);
console.log(arr1);



//завдання 5


const personFragments = persons.map(person => `${person.name} from ${person.city} born in ${new Date().getFullYear() - person.age}`);
console.log(personFragments); // ['John from Boston born in 1998', 'Sarah from New York born in 1990', 'David from Chicago born in 2002', 'Jessica from Los Angeles born in 1996', 'Chris from San Francisco born in 1989']



//завдання 6


const personsOver20 = persons.filter(person => person.age > 20);
console.log(personsOver20); // [{ name: 'John', age: 23, city: 'Boston' }, { name: 'Sarah', age: 31, city: 'New York' }, { name: 'Jessica', age: 27, city: 'Los Angeles' }, { name: 'Chris', age: 34, city: 'San Francisco' }]




//завдання 7

const { name, city } = person;
console.log(name); // 'John'
console.log(city); // 'Boston'


const [firstPerson] = persons;
console.log(firstPerson); // { name: 'John', age: 23, city: 'Boston' }



//завдання 8



// функція getUserData
function getUserData(name) {
  const user = persons.find(person => person.name === name);
  if (user) {
    return user;
  } else {
    throw new Error('Unable to find user');
  }
}

// функція showUserInfo
function showUserInfo(name) {
  console.log('Loading');
  try {
    const user = getUserData(name);
    console.log(`Name: ${user.name}, Age: ${user.age}, City: ${user.city}`);
  } catch (error) {
    console.error(error.message);
  }
  console.log('Loading finished');
}

// тестування функції showUserInfo
showUserInfo('John'); // виведе: Loading, Name: John, Age: 23, City: Boston, Loading finished
showUserInfo('Sarah'); // виведе: Loading, Unable to find user, Loading finished



//завдання 9

function textToLetters(text) {
  return Array.from(text);
}


//завдання 10

function reverseLetters(word) {
  return Array.from(word).reverse();
}


//завдання 11

function isJSFile(filename) {
  return filename.endsWith('.js');
}


//завдання 12

function sentenceToWords(sentence) {
  return sentence.split(' ');
}


//завдання 13

function replaceWord(text, oldWord, newWord) {
  return text.replace(oldWord, newWord);
}
