//завдання 1
function average(...args) {
  return args.reduce((acc, val) => acc + val, 0) / args.length;
}


//завдання 2
function values(f, low, high) {
  const arr = [];
  for (let i = low; i <= high; i++) {
    arr.push(f(i));
  }
  return arr;
}


//завдання 3
function callWithContext(obj, callback) {
  callback.call(obj);
}

const person = {
  name: "John",
  age: 30,
  sayHello() {
    const date = new Date().toLocaleDateString();
    console.log(`Today is ${date}! Happy birthday ${this.name}.`);
  },
};

callWithContext(person, person.sayHello);


//завдання 4
function createCounter() {
  let value = 0;
  return {
    increment() {
      value++;
    },
    getValue() {
      return value;
    },
  };
}

const counter = createCounter();
counter.increment();
console.log(counter.getValue()); // 1



// завдання 5
function getGreeting() {
  let lastCalledName = null;
  let lastGreeting = null;

  return function (name) {
    if (name === lastCalledName) {
      console.log("Returning cached greeting.");
      return lastGreeting;
    } else {
      lastCalledName = name;
      lastGreeting = `Hello ${name}`;
      return lastGreeting;
    }
  };
}

const greet = getGreeting();
console.log(greet("John")); // Hello John
console.log(greet("Bob")); // Hello Bob
console.log(greet("John")); // Returning cached greeting. Hello John



// завдання 6
function createAdder(num1) {
  return function (num2) {
    return num1 + num2;
  };
}

const add5 = createAdder(5);
console.log(add5(10)); // 15

const add10 = createAdder(10);
console.log(add10(20)); // 30



// завдання 7
function checkIfExists(arr) {
  return function (val) {
    return arr.includes(val);
  };
}

const fruits = ["apple", "banana", "orange"];
const hasFruit = checkIfExists(fruits);
console.log(hasFruit("banana")); // true
console.log(hasFruit("grape")); // false



// завдання 8
const capitalizeProperty = arr => arr.map(obj => ({ ...obj, name: obj.name.toUpperCase() }));


//завдання 9
// функція, яку будемо викликати з різними контекстами
function greet2() {
  console.log(`Hello, ${this.name}!`);
}

const person1 = { name: 'Alice' };
const person2 = { name: 'Bob' };

// виклик функції greet з контекстом person1 за допомогою методу call
greet.call(person1); // "Hello, Alice!"

// виклик функції greet з контекстом person2 за допомогою методу apply
greet.apply(person2); // "Hello, Bob!"

// створення нової функції з фіксованим контекстом person1 за допомогою методу bind
const greetPerson1 = greet.bind(person1);
greetPerson1(); // "Hello, Alice!"


//завдання 10
function callCallback(callback, ...args) {
  const functionName = callback.name || 'anonymous function';
  const time = new Date().toLocaleTimeString();
  console.log(`Calling function '${functionName}' with arguments [${args.join(', ')}] at ${time}`);
  callback(...args);
}



// завдання 11
function memoize(func) {
  let lastArgs = null;
  let lastResult = null;
  let lastCalledTime = null;
  
  return function(...args) {
    const now = new Date().getTime();
    if (lastArgs && args.length === lastArgs.length && args.every((arg, i) => arg === lastArgs[i]) && now - lastCalledTime < 10000) {
      console.log('Returning cached result');
      return lastResult;
    } else {
      console.log('Computing result');
      lastArgs = args;
      lastResult = func(...args);
      lastCalledTime = now;
      return lastResult;
    }
  }
}
