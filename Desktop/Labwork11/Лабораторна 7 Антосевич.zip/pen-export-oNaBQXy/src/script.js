//завдання 1
function invokeAfterDelay(func, delay) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const result = func();
      resolve(result);
    }, delay);
  });
}

invokeAfterDelay(() => Math.floor(Math.random() * 11), 1000)
  .then((result) => console.log(result));


//завдання 2
function produceRandomAfterDelay(delay) {
  return invokeAfterDelay(() => Math.floor(Math.random() * 11), delay);
}

Promise.all([produceRandomAfterDelay(1000), produceRandomAfterDelay(2000)])
  .then((results) => {
    const sum = results.reduce((acc, val) => acc + val, 0);
    console.log(sum);
  });


//завдання 3
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


//завдання 4
const users = [
  { id: 0, name: 'John', age: 30, city: 'New York' },
  { id: 1, name: 'Mary', age: 25, city: 'Los Angeles' },
  { id: 2, name: 'David', age: 40, city: 'Chicago' },
  { id: 3, name: 'Julia', age: 35, city: 'Houston' },
];

function getUser(id) {
  return new Promise((resolve, reject) => {
    const user = users.find(user => user.id === id);
    if (user) {
      setTimeout(() => {
        resolve(user);
      }, 1000);
    } else {
      reject('User not found');
    }
  });
}



//завдання 5
async function loadUsers(ids) {
  try {
    const promises = ids.map(id => getUser(id));
    const users = await Promise.all(promises);
    return users;
  } catch (error) {
    console.error(error);
    throw error;
  }
}

loadUsers([0, 1, 2, 3])
  .then(users => console.log(users))
  .catch(error => console.error(error));




//завдання 6
function logCall(callback) {
  return new Promise(resolve => {
    setTimeout(() => {
      const result = callback();
      console.log(new Date().toLocaleTimeString());
      resolve(result);
    }, 1000);
  });
}

logCall(() => Math.floor(Math.random() * 11))
  .then((result) => console.log(result))
  .then(() => logCall(() => Math.floor(Math.random() * 11)))
  .then((result) => console.log(result))
  .then(() => logCall(() => Math.floor(Math.random() * 11)))
  .then((result) => console.log(result))
  .then(() => logCall(() => Math.floor(Math.random() * 11)))
  .then((result) => console.log(result));




//завдання 7
async function showUsers(ids) {
  console.log('loading');
  try {
    const users = await loadUsers(ids);
    console.log(users);
  } catch (error) {
    console.error(error);
  } finally {
    console.log('loading finished');
  }
}

showUsers([0, 1, 2, 3]);
